import React from 'react';

function About() {
  return (
    <div>
      <h1>About</h1>
      <p>This is a simple React application.</p>
    </div>
  );
}

export default About;
